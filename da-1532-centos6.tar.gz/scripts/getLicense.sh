#!/bin/sh

LICENSE=/usr/local/directadmin/conf/license.key
DACONF_FILE=/usr/local/directadmin/conf/directadmin.conf

printf "" > $LICENSE

chmod 600 $LICENSE
chown diradmin:diradmin $LICENSE
exit 0;
